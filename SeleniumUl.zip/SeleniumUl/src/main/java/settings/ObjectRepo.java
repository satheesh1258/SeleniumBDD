package settings;

import java.util.LinkedHashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;



public class ObjectRepo {
	public static WebDriver driver;
	public static Map<String, Object> data = new LinkedHashMap<String, Object>();
}
