package helper;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;


import io.github.bonigarcia.wdm.WebDriverManager;

public class ChromeBrowser {
	

	public Capabilities getChromeCapabilities() {
		ChromeOptions option = new ChromeOptions();
		option.addArguments("start-maximized");
		DesiredCapabilities chrome = new DesiredCapabilities();
		chrome.setJavascriptEnabled(true);
		chrome.setCapability(ChromeOptions.CAPABILITY, option);
		return chrome;
	}
	
	@SuppressWarnings("deprecation")
	public WebDriver getChromeDriver() {
		
		  WebDriverManager.chromedriver().setup();
		  WebDriver driver = new ChromeDriver(getChromeCapabilities());
	      return driver;
	  
	}
	
	  

}
