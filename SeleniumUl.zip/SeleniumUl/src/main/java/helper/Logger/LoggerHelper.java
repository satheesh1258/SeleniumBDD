package helper.Logger;


import org.apache.logging.log4j.*;



public class LoggerHelper {

	@SuppressWarnings("rawtypes")
	public static Logger getLogger(Class cls) {
		return LogManager.getLogger(cls);
	}
}