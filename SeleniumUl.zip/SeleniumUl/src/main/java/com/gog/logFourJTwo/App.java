package com.gog.logFourJTwo;




import org.apache.logging.log4j.*;

import Utilites.Property;
import helper.Logger.LoggerHelper;

public class App 
{
	//public static Property prop = new Property(");
	private static final Logger log = LoggerHelper.getLogger(App.class);
	public static void main( String[] args )
    {
	//System.out.println(System.getProperty("user.dir")+"/src/test/resources/configs/extent-config.xml");
        log.info("kkk");
    }
}
