package Utilites;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;



public class ResourceHelper {
	public static String getResourcePath(String resource) {
		String path = getBaseResourcePath() + resource;
		return path;
	}

	public static String getBaseResourcePath() {

		// String path = ResourceHelper.class.getClass().getResource("/").getPath();
//		System.out.println(System.getProperty("user.dir") + "\\src\\test\\resources\\configs\\log4j.properties");
		String path = System.getProperty("user.dir") + "\\src\\test\\resources\\";
		return path;
	}

	public static InputStream getResourcePathInputStream(String resource) throws FileNotFoundException {
		return new FileInputStream(ResourceHelper.getResourcePath(resource));
	}

}
