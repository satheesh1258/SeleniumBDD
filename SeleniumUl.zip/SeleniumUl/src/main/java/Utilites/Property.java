package Utilites;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;

public class Property {
	Properties properties;

	public Property(String mapFile) {
		properties = new Properties();
		try {
			FileInputStream in = new FileInputStream(mapFile);
			properties.load(in);
			in.close();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	public String ReadProperty(String propkey) {
		try {
			String propval = properties.getProperty(propkey);
			return propval;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "false";
	}

	public By getLocator(String logicalElementName) throws Exception {
		String locator = properties.getProperty(logicalElementName);

		String locatorType = locator.split(">")[0];

		String locatorValue = locator.split(">")[1];

		if (locatorType.toLowerCase().equals("id"))
			return By.id(locatorValue);
		else if (locatorType.toLowerCase().equals("name"))
			return By.name(locatorValue);
		else if ((locatorType.toLowerCase().equals("classname")) || (locatorType.toLowerCase().equals("class")))
			return By.className(locatorValue);
		else if ((locatorType.toLowerCase().equals("tagname")) || (locatorType.toLowerCase().equals("tag")))
			return By.className(locatorValue);
		else if (locatorType.toLowerCase().equals("partiallinktext"))
			return By.partialLinkText(locatorValue);
		else if ((locatorType.toLowerCase().equals("linktext")) || (locatorType.toLowerCase().equals("link")))
			return By.linkText(locatorValue);
		else if ((locatorType.toLowerCase().equals("cssselector")) || (locatorType.toLowerCase().equals("css")))
			return By.cssSelector(locatorValue);
		else if (locatorType.toLowerCase().equals("xpath"))
			return By.xpath(locatorValue);
		else
			throw new Exception("Locator type '" + locatorType + "' not defined!...");
	}

	public String getlocatorString(String logicalElementName) throws Exception {
		String locator = properties.getProperty(logicalElementName);

		String[] locDetails = locator.split(">");
		if (locDetails.length >= 3) {
			return locDetails[1];
		} else {
			throw new Exception("Locator Name is not defined");
		}

	}

	public String getFieldName(String logicalElementName) throws Exception {

		String locator = properties.getProperty(logicalElementName);

		String[] locDetails = locator.split(">");
		if (locDetails.length >= 3) {
			return locDetails[2];
		} else {
			throw new Exception("Locator Name is not defined");
		}

	}

	public String getReportConfigPath() {
		String reportConfigPath = properties.getProperty("reportConfigPath");
		if (reportConfigPath != null)
			return reportConfigPath;
		else
			throw new RuntimeException(
					"Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");
	}
}
