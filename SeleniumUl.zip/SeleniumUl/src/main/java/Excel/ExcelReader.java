package Excel;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
	private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
//	private static XSSFCell Cell;
//	private static XSSFRow Row;

	public static void main(String[] args) throws IOException {
		FileInputStream Excelfile = new FileInputStream(System.getProperty("user.dir") + "");
		ExcelWBook = new XSSFWorkbook(Excelfile);
		ExcelWSheet = ExcelWBook.getSheet("AnnDetails");
		System.out.println(ExcelWSheet.getLastRowNum() + " " + ExcelWSheet.getRow(0).getLastCellNum() + " "
				+ ExcelWSheet.getRow(0).getCell(0).getStringCellValue());
		System.out.println(EID("TC02", "Column2"));
	}

	public static String EID(String TCID, String Colu) {
		String Data = null;
		FileInputStream Excelfile = null;
		try {
			Excelfile = new FileInputStream(System.getProperty("user.dir") + "");
			ExcelWBook = new XSSFWorkbook(Excelfile);
			ExcelWSheet = ExcelWBook.getSheet("AnnDetails");
			int CellNumber = 0, ColNumber = 0;
			for (int jaw = 0; jaw < ExcelWSheet.getLastRowNum(); jaw++) {
				if (ExcelWSheet.getRow(jaw).getCell(0).getStringCellValue().equals(TCID)) {
					CellNumber = jaw;
					jaw = ExcelWSheet.getLastRowNum();
				}
			}
//			String values = null;
			if(CellNumber>0) {
				for(int rows = 0; rows<=ExcelWSheet.getRow(0).getLastCellNum();rows++)
				{
					if(ExcelWSheet.getRow(0).getCell(rows).getStringCellValue().equals(Colu))
					{
						ColNumber = rows;
						Data = ExcelWSheet.getRow(CellNumber).getCell(ColNumber).getStringCellValue();
						rows = ExcelWSheet.getRow(0).getLastCellNum();
					}
				}
			}else {
				System.out.println("TestCase Id not Exists");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return Data;

	}
}
