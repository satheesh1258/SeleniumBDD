package Runner;

import org.testng.annotations.BeforeClass;

import com.vimalselvam.cucumber.listener.Reporter;

import Utilites.Property;
import Utilites.ResourceHelper;

import java.io.File;

import org.testng.annotations.AfterSuite;

import helper.*;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import settings.ObjectRepo;


@CucumberOptions(features = "src/test/resources/featurefile/", glue = {
		"stepdefinition" }, monochrome = true, plugin = { "pretty", "json:target/Search.json",
				"html:target/cucumber"})

public class TestRunner extends AbstractTestNGCucumberTests {
	public static Property map = new Property(
			ResourceHelper.getResourcePath("configs\\Configuration.properties"));

	@BeforeClass
	public void before() {
//		ChromeBrowser browser = new ChromeBrowser();
//		ObjectRepo.driver = browser.getChromeDriver();
	}

	@AfterSuite
	public void after() {
		
//		ObjectRepo.driver.close();
	}
}
