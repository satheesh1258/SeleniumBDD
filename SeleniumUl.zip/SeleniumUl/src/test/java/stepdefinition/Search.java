package stepdefinition;

import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.gog.logFourJTwo.App;

import Runner.TestRunner;
import Waits.WaitHelper;
import helper.Logger.LoggerHelper;
import io.cucumber.java.en.*;
import settings.ObjectRepo;

public class Search extends TestRunner {
	
	WebDriver driver;
	public Search() {
//		this.driver = ObjectRepo.driver;
	}
//	WaitHelper wait = new WaitHelper(ObjectRepo.driver);
	private static final Logger log = LoggerHelper.getLogger(Search.class);
	@Given(": Vadidate Google page")
	public void vadidate_Google_page()  {
		log.info("This is google message");
//		ObjectRepo.driver.get("https://www.google.com");
//		wait.waitForElement(ObjectRepo.driver.findElement(By.name("q")), 60);
	}

	@When(": Enter Cucumber in search page")
	public void enter_Cucumber_in_search_page() {

//		ObjectRepo.driver.findElement(By.name("q")).sendKeys("Cucumber");

	}

	@Then(": Press Enter")
	public void press_Enter() {
		// Write code here that turns the phrase above into concrete actions
//		ObjectRepo.driver.navigate().to("https://www.facebook.com");
	}

}
